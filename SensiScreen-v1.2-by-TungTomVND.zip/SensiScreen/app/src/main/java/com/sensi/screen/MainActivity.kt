package com.sensi.screen

import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.ImageView
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import rikka.shizuku.Shizuku

private const val LV_NONE = 0
private const val LV_OK = 1
private const val LV_WARN = 2
private const val LV_BAD = 3

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var tvShizuku: TextView
    private lateinit var tvRoot: TextView
    private lateinit var tvA11y: TextView
    private lateinit var tvApps: TextView
    private lateinit var etW: EditText
    private lateinit var etH: EditText
    private lateinit var etD: EditText
    private lateinit var swEnable: SwitchCompat
    private lateinit var rgMode: RadioGroup
    private var rootText = "Chưa kiểm tra"
    private var rootLevel = LV_NONE

    private val permListener = Shizuku.OnRequestPermissionResultListener { _, _ ->
        runOnUiThread { refresh() }
    }
    private val binderListener = Shizuku.OnBinderReceivedListener { runOnUiThread { refresh() } }
    private val deadListener = Shizuku.OnBinderDeadListener { runOnUiThread { refresh() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)

        tvShizuku = findViewById(R.id.tvShizuku)
        tvRoot = findViewById(R.id.tvRoot)
        tvA11y = findViewById(R.id.tvA11y)
        tvApps = findViewById(R.id.tvApps)
        etW = findViewById(R.id.etW)
        etH = findViewById(R.id.etH)
        etD = findViewById(R.id.etD)
        swEnable = findViewById(R.id.swEnable)
        rgMode = findViewById(R.id.rgMode)

        // Hiệu ứng: thẻ hiện dần, logo bật ra, nút co lại khi nhấn
        Anim.cascade(findViewById<ViewGroup>(R.id.content), from = 1)
        val logo = findViewById<ImageView>(R.id.ivLogo)
        Anim.pop(logo)
        logo.setOnClickListener { Anim.wobble(logo) }
        for (id in intArrayOf(
            R.id.btnShizuku, R.id.btnRoot, R.id.btnApps,
            R.id.btnA11y, R.id.btnTest, R.id.btnReset
        )) {
            Anim.pressable(findViewById<View>(id))
        }

        etW.setText(prefs.width.toString())
        etH.setText(prefs.height.toString())
        if (prefs.density > 0) etD.setText(prefs.density.toString())

        when (prefs.mode) {
            "shizuku" -> rgMode.check(R.id.rbShizuku)
            "root" -> rgMode.check(R.id.rbRoot)
            else -> rgMode.check(R.id.rbAuto)
        }
        rgMode.setOnCheckedChangeListener { _, id ->
            prefs.mode = when (id) {
                R.id.rbShizuku -> "shizuku"
                R.id.rbRoot -> "root"
                else -> "auto"
            }
            refresh()
        }

        swEnable.isChecked = prefs.enabled
        swEnable.setOnCheckedChangeListener { _, checked ->
            prefs.enabled = checked
            if (!checked) ScreenController.reset(this)
        }

        findViewById<Button>(R.id.btnShizuku).setOnClickListener { requestShizuku() }
        findViewById<Button>(R.id.btnRoot).setOnClickListener { checkRoot() }
        findViewById<Button>(R.id.btnApps).setOnClickListener {
            saveFields()
            startActivity(Intent(this, AppPickerActivity::class.java))
        }
        findViewById<Button>(R.id.btnA11y).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnTest).setOnClickListener {
            if (!saveFields()) return@setOnClickListener
            ScreenController.apply(
                this, "manual",
                Profile(prefs.width, prefs.height, prefs.density),
                isManual = true
            ) { r ->
                runOnUiThread {
                    toast(if (r.ok) "Đã áp dụng. Bấm \"Khôi phục\" để trả về như cũ" else "Lỗi: ${r.output}")
                }
            }
        }
        findViewById<Button>(R.id.btnReset).setOnClickListener {
            ScreenController.reset(this, force = true) { r ->
                runOnUiThread { toast(if (r.ok) "Đã khôi phục màn hình" else "Lỗi: ${r.output}") }
            }
        }

        try {
            Shizuku.addRequestPermissionResultListener(permListener)
            Shizuku.addBinderReceivedListener(binderListener)
            Shizuku.addBinderDeadListener(deadListener)
        } catch (_: Throwable) {
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    override fun onDestroy() {
        try {
            Shizuku.removeRequestPermissionResultListener(permListener)
            Shizuku.removeBinderReceivedListener(binderListener)
            Shizuku.removeBinderDeadListener(deadListener)
        } catch (_: Throwable) {
        }
        super.onDestroy()
    }

    private fun requestShizuku() {
        try {
            if (!ShellRunner.shizukuRunning()) {
                toast("Shizuku chưa chạy. Mở app Shizuku và khởi động nó trước.")
                return
            }
            if (ShellRunner.shizukuReady()) {
                toast("Đã có quyền Shizuku")
            } else {
                Shizuku.requestPermission(100)
            }
        } catch (t: Throwable) {
            toast("Không tìm thấy Shizuku: ${t.message}")
        }
    }

    private fun checkRoot() {
        rootText = "Đang kiểm tra…"
        rootLevel = LV_WARN
        refresh()
        Thread {
            val ok = ShellRunner.rootAvailable()
            rootText = if (ok) "Có root" else "Không có"
            rootLevel = if (ok) LV_OK else LV_NONE
            runOnUiThread { refresh() }
        }.start()
    }

    /** Đọc 3 ô nhập, kiểm tra rồi lưu. Trả về false nếu giá trị sai. */
    private fun saveFields(): Boolean {
        val w = etW.text.toString().trim().toIntOrNull()
        val h = etH.text.toString().trim().toIntOrNull()
        val dText = etD.text.toString().trim()
        val d = if (dText.isEmpty()) 0 else dText.toIntOrNull()
        if (w == null || h == null || d == null || w !in 200..10000 || h !in 200..10000 || (d != 0 && d !in 72..800)) {
            toast("Rộng/Cao phải từ 200 đến 10000, density từ 72 đến 800 (hoặc để trống)")
            return false
        }
        prefs.width = w
        prefs.height = h
        prefs.density = d
        return true
    }

    private fun setStatus(tv: TextView, text: String, level: Int) {
        val color = ContextCompat.getColor(
            this,
            when (level) {
                LV_OK -> R.color.ok
                LV_WARN -> R.color.warn
                LV_BAD -> R.color.bad
                else -> R.color.neutral
            }
        )
        tv.text = text
        tv.compoundDrawableTintList = ColorStateList.valueOf(color)
    }

    private fun refresh() {
        when {
            ShellRunner.shizukuReady() -> setStatus(tvShizuku, "Sẵn sàng", LV_OK)
            ShellRunner.shizukuRunning() -> setStatus(tvShizuku, "Đang chạy · chưa cấp quyền", LV_WARN)
            else -> setStatus(tvShizuku, "Chưa chạy", LV_NONE)
        }
        setStatus(tvRoot, rootText, rootLevel)

        val a11y = (Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: "").contains(packageName)
        if (a11y) setStatus(tvA11y, "Đã bật", LV_OK)
        else setStatus(tvA11y, "Chưa bật (cần bật)", LV_BAD)

        val n = prefs.apps().size
        if (n > 0) setStatus(tvApps, "$n ứng dụng", LV_OK)
        else setStatus(tvApps, "Chưa chọn", LV_NONE)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
