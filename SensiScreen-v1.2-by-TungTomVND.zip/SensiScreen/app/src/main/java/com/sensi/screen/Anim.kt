package com.sensi.screen

import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator

/** Các hiệu ứng nhỏ cho giao diện: nhấn nút co lại rồi nảy về, hiện dần từng thẻ, logo bật ra. */
object Anim {

    /** Nhấn xuống thì co lại, thả ra thì nảy về. Không chặn sự kiện bấm. */
    @SuppressLint("ClickableViewAccessibility")
    fun pressable(v: View, pressedScale: Float = 0.94f) {
        v.setOnTouchListener { view, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN ->
                    view.animate().scaleX(pressedScale).scaleY(pressedScale)
                        .setDuration(90).setInterpolator(DecelerateInterpolator()).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.animate().scaleX(1f).scaleY(1f)
                        .setDuration(280).setInterpolator(OvershootInterpolator(3f)).start()
            }
            false
        }
    }

    /** Các view con trượt nhẹ từ dưới lên và hiện dần, lần lượt từng cái. */
    fun cascade(parent: ViewGroup, from: Int = 0) {
        val dy = 28f * parent.resources.displayMetrics.density
        for (i in from until parent.childCount) {
            val c = parent.getChildAt(i)
            c.alpha = 0f
            c.translationY = dy
            c.animate().alpha(1f).translationY(0f)
                .setStartDelay((i - from) * 70L + 120L)
                .setDuration(420)
                .setInterpolator(DecelerateInterpolator(1.6f))
                .start()
        }
    }

    /** Logo phóng to từ nhỏ ra, nảy nhẹ. */
    fun pop(v: View) {
        v.alpha = 0f
        v.scaleX = 0.6f
        v.scaleY = 0.6f
        v.animate().alpha(1f).scaleX(1f).scaleY(1f)
            .setStartDelay(60)
            .setDuration(520)
            .setInterpolator(OvershootInterpolator(2.2f))
            .start()
    }

    /** Lắc nhẹ, dùng khi chạm vào logo. */
    fun wobble(v: View) {
        ObjectAnimator.ofFloat(v, View.ROTATION, 0f, -10f, 8f, -5f, 2f, 0f)
            .setDuration(520)
            .start()
    }

    /** Phình to rồi nảy về, dùng cho ô tích chọn. */
    fun bounce(v: View) {
        v.animate().scaleX(1.3f).scaleY(1.3f).setDuration(110).withEndAction {
            v.animate().scaleX(1f).scaleY(1f)
                .setDuration(180).setInterpolator(OvershootInterpolator(3f)).start()
        }.start()
    }
}
