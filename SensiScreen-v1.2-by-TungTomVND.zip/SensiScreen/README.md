# SensiScreen — by TungTomVND

Đổi kích thước màn hình (`wm size` / `wm density`) **riêng cho từng ứng dụng bạn chọn**.
Khi thoát ra màn hình chính hoặc sang ứng dụng khác, màn hình tự trả về như cũ.

Giao diện xanh dương - trắng, thẻ bo góc, hiệu ứng khi bấm nút, logo TungTom + tay cầm game, tự đổi sáng/tối theo hệ thống.

## Build
**Cách 1 – Android Studio** (Koala trở lên): **Open** thư mục `SensiScreen` → chờ Gradle sync (cần internet) → **Build > Build APK(s)**.

**Cách 2 – GitHub Actions (không cần cài gì):**
1. Tạo repo GitHub mới, tải lên *nội dung* của thư mục `SensiScreen` (có cả thư mục `.github`).
2. Vào tab **Actions** → chạy workflow **Build APK** (hoặc cứ push là tự chạy).
3. Khi xong, mở lần chạy đó → mục **Artifacts** → tải `SensiScreen-debug-apk`, giải nén ra file `.apk` rồi cài.

## Dùng
1. Mở **Shizuku** (hoặc có root) → trong SensiScreen bấm **Cấp quyền Shizuku** / **Kiểm tra Root**.
2. Bấm **Bật dịch vụ Trợ năng** → bật SensiScreen.
3. Nhập kích thước (ví dụ 1000 x 1000) → **Chọn ứng dụng** → tick ứng dụng cần chỉnh
   (nhấn giữ một ứng dụng để đặt kích thước riêng cho nó).
4. Có thể bấm **Thử ngay** / **Khôi phục** để kiểm tra bằng tay.

## Nếu bị kẹt kích thước
Bấm **Khôi phục** trong app, hoặc chạy trong Brevent/ADB:
```
wm size reset
wm density reset
```
